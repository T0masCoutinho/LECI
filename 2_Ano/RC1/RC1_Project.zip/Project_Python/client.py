
import socket
import signal
import sys

def signal_handler(sig, frame):
    print('\nDone!')
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
print('Press Ctrl+C to exit...')


client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(("127.0.0.1", 5055))

while True:
    message = client_socket.recv(1024).decode()
    print(message)

    if "Congratulations" in message:
            break

    guess = input("Your guess: ")
    client_socket.send(guess.encode())

client_socket.close()