import socket
import threading
import random
import signal
import sys

# Signal handler to gracefully close the server
def signal_handler(sig, frame):
    print("\nShutting down server...")
    server.close()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
print("Press Ctrl+C to exit...")

def handle_client(client_socket, client_address, clients):
    try:
        client_socket.settimeout(300)  # Set timeout for 5 minutes
        client_socket.send(b"Welcome to 'Guess the Number'! Enter your name: ")
        player_name = client_socket.recv(1024).decode().strip()

        lower_bound, upper_bound = 1, 100
        target_number = random.randint(lower_bound, upper_bound)
        attempts = 0

        client_socket.send(
            f"Hello {player_name}! Guess a number between {lower_bound} and {upper_bound}: ".encode()
        )

        while True:
            try:
                guess = int(client_socket.recv(1024).decode().strip())
                attempts += 1

                if guess < target_number:
                    client_socket.send(b"Too low! Try again: ")
                elif guess > target_number:
                    client_socket.send(b"Too high! Try again: ")
                elif guess == target_number:
                    client_socket.send(
                        f"Congratulations {player_name}, you guessed it in {attempts} attempts!".encode()
                    )
                    break
            except ValueError:
                client_socket.send(b"Invalid input. Please enter a number: ")

        clients[client_address] = (player_name, attempts)

    except (socket.timeout, socket.error):
        print(f"Client {client_address} disconnected or caused an error.")
    finally:
        client_socket.close()

ip_addr = "0.0.0.0"
tcp_port = 5055

# Initialize the server
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((ip_addr, tcp_port))
server.listen(5)  # Maximum backlog of connections
print(f"Listening on {ip_addr}:{tcp_port}")

# Dictionary to track client information
clients = {}

# Server main loop
while True:
    try:
        client_sock, address = server.accept()
        print(f"New connection from {address}")
        client_handler = threading.Thread(
            target=handle_client, args=(client_sock, address, clients), daemon=True
        )
        client_handler.start()
    except KeyboardInterrupt:
        signal_handler(None, None)





